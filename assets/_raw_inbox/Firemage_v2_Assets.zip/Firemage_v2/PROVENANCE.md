# Firemage — creation notes

Publisher: watsu. Artwork was generated with the built-in image-generation tool, selected into animation sequences, and mechanically exported using nearest-neighbour sampling, hard pixel alpha, fixed origins, and controlled palettes. The character uses 15 visible colours; the effects share 7 visible colours.

The PNG and Aseprite bytes are preserved from the validated Amber Mage v2 assets; only product filenames and documentation have been rebranded. No third-party reference sprite pixels are included.

The optional working-files download contains the generated atlases with their original alpha and the generation prompts. Some source frames were not selected for the native animations. The native assets in the main download are the game-scale exports.
