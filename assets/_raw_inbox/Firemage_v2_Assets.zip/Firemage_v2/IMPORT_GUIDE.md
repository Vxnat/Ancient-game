# Firemage — import and animation guide

## Character animations

All character frame canvases are **96 × 80 pixels**, with the same **15 visible colours** plus transparency and a shared origin **(40, 72)** from the top-left. The standing mage is approximately 43 pixels tall including the hat.

| Animation | Frames | Total duration | Release event | Behaviour |
| --- | ---: | ---: | --- | --- |
| Idle | 6 | 960 ms | — | Loop |
| Run | 10 | 800 ms | — | Loop, in place |
| Cast | 8 | 1,280 ms | Frame 4 / 480 ms | Play once; original general cast |
| Quick bolt | 6 | 600 ms | Frame 2 / 200 ms | Play once; horizontal staff thrust |
| Charged fireball | 8 | 1,220 ms | Frame 4 / 640 ms | Play once; overhead wind-up and release |
| Staff slam | 8 | 1,020 ms | Frame 4 / 460 ms | Play once; grounded strike |

Frames and indices are zero-based. All new attacks start and finish on the exact original neutral idle frame. A repeated overhead pose holds the charge; it is not an extra unique drawing.

## Spell effects

Effects are separate transparent sprites. All six effects share a restrained **7-colour amber palette**, stored in `effects/Spell_Palette.gpl`. They do not change the character's palette.

| Effect | Frame canvas | Frames | Duration | Origin | Behaviour |
| --- | --- | ---: | ---: | --- | --- |
| Bolt flight | 40 × 24 | 6 | 480 ms | (28, 12) | Loop, points right |
| Bolt impact | 48 × 48 | 6 | 440 ms | (24, 24) | Play once |
| Fireball flight | 56 × 40 | 6 | 600 ms | (36, 20) | Loop, points right |
| Fireball impact | 80 × 80 | 8 | 660 ms | (40, 40) | Play once |
| Ground nova | 128 × 80 | 8 | 830 ms | (64, 72) | Play once, anchored to ground |
| Protective ward | 80 × 80 | 6 | 720 ms | (40, 40) | Active loop, transparent interior |

Impact and eruption animations finish on a fully transparent frame. Projectile flight frames stay at a fixed local origin; move the projectile object in your game.

## Connect attacks to spells

`Spells.json` provides the bindings, event times, origins, and attachment points.

| Spell | Character animation | Effect to spawn | Spawn position in character frame |
| --- | --- | --- | --- |
| Amber bolt | Quick bolt | Bolt flight; bolt impact on collision | (82, 51) |
| Fireball | Charged fireball | Fireball flight; fireball impact on collision | (73, 30) |
| Ground nova | Staff slam | Ground nova | (58, 72) |
| Ward | Original cast | Protective ward | (40, 50) |

Spawn once when entering the release frame. Convert a frame-space position to a position relative to the character origin by subtracting **(40, 72)**. For example, the bolt starts at **(42, -21)** relative to the character origin.

On a projectile collision, remove the flight effect and play its impact once at the collision point. Ground nova stays at its world position. Attach the ward's origin at **(0, -22)** relative to the character origin so it follows the mage. Return the character to idle when each attack finishes.

The JSON describes visual timing and placement. Damage, collision shapes, aiming, movement speed, costs, and cooldowns belong to your game. Preview demonstrations show one possible use of the assets.

## Import

1. Slice a character strip in `sheets/` into **96 × 80** frames, with no extra spacing. Slice each effect strip using its own frame size above.
2. Use nearest-neighbour / point filtering. Keep pixels at integer display scales where practical.
3. Character origin: **(40, 72)**, normalised **(0.416667, 0.9)**. Ground baseline: y = 72.
4. Preserve the full canvas and origins. Independent trimming or recentering changes the alignment.
5. Mirror around the origin for left-facing use. If exporting a horizontally mirrored 96-pixel-wide character image instead, use origin **(56, 72)**. An effect exported as a mirrored image uses x-origin `frameWidth - originalOriginX`.

The character's movement remains in place, controlled by your game. No world-space root-motion track is included.

## Combined character atlas

`sheets/Firemage_All.png` is **960 × 480**, with 10 columns and 6 rows:

| Row | Animation | Valid columns | Aseprite timeline frames |
| ---: | --- | --- | --- |
| 0 | Idle | 0–5 | 0–5 |
| 1 | Run | 0–9 | 6–15 |
| 2 | Cast | 0–7 | 16–23 |
| 3 | Quick bolt | 0–5 | 24–29 |
| 4 | Charged fireball | 0–7 | 30–37 |
| 5 | Staff slam | 0–7 | 38–45 |

Unused atlas cells are empty and are not animation frames. `Firemage.json` contains every frame rectangle and duration.


## Editing

Open Firemage.aseprite to edit the character. Each effect has a separate Aseprite file in effects/<effect>/. The original general cast includes its small baked casting spark. New attacks use separate effects. GIFs repeat for inspection; attack and impact tags play once in the metadata.
