# Firemage v2

By **watsu**. Free to download; donations are optional.

A side-view pixel mage with **6 character animations** and **6 spell-effect animations**. Includes 46 character frame cells and 40 effect frame cells; totals include held poses and transparent finishing frames.

## Contents

- Character: idle, run, cast, quick bolt, charged fireball, and staff slam.
- Effects: bolt flight/impact, fireball flight/impact, ground nova, and protective ward.
- Transparent PNG strips and individual frames.
- Editable Aseprite files with animation tags, durations, and origins.
- JSON timing, atlas rectangles, release events, and spell attachments.
- Palettes, animated previews, and an import guide.

## Quick import

Character canvas: **96 × 80 px**. Origin: **(40, 72)**. The standing mage is approximately **43 px tall** including the hat. Use point/nearest-neighbour filtering and keep the full canvas. The character faces right and can be mirrored for left-facing use.

Read **IMPORT_GUIDE.md** for frame sizes, effect origins, timings, and attack-to-spell bindings. Character data is in **Firemage.json**; spell data is in **Spells.json**.

Movement includes idle and run. Jump, fall, hurt, death, and wall actions are not included. Game code and engine project templates are not included.

## License

Personal and commercial game use and modification are allowed. Credit is optional; “Firemage by watsu” is appreciated. Standalone redistribution or sale of the original or modified assets is not allowed. Read **LICENSE.txt** for the complete terms. Optional donations do not change these permissions.

## Creation

AI-generated artwork with curated animation frames and controlled pixel exports. The native sprite pixels are unchanged from the earlier Amber Mage v2 working version. The public name is Firemage. Larger generated atlases and prompts are supplied in the separate, optional **Firemage_v2_Working_Files.zip** download.
